﻿using System;

namespace Exe5
{
    class Program
    {
        static void Main(string[] args)
        {
            char inicio = 'A'; 
            char fim = 'C'; 
            char trabalho = 'B';
            int discos = 3;

            Console.WriteLine("Torre de Hanoi, com recursividade");
            torreHanoiRecursividade(discos, inicio, fim, trabalho);

        }

        static void torreHanoiRecursividade(int discos, char inicio, char fim, char trabalho)
        {
            if (discos > 0)
            {
                torreHanoiRecursividade(discos - 1, inicio, trabalho, fim);
                Console.WriteLine($"Mova o disco de {inicio} para {fim}");
                torreHanoiRecursividade(discos - 1, trabalho, fim, inicio);

            }
        }
    }
}
